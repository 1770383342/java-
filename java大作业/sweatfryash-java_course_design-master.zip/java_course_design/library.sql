/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : library

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 09/01/2019 17:09:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `psd` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'hhh', '123456');

-- ----------------------------
-- Table structure for allbook
-- ----------------------------
DROP TABLE IF EXISTS `allbook`;
CREATE TABLE `allbook`  (
  `图书ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ISBN` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `存放位置` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `状态` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`图书ID`) USING BTREE,
  INDEX `ISBN`(`ISBN`) USING BTREE,
  CONSTRAINT `allbook_ibfk_1` FOREIGN KEY (`ISBN`) REFERENCES `booklist` (`ISBN`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of allbook
-- ----------------------------
INSERT INTO `allbook` VALUES ('001', '978-7-115-41064-1', '阅览室', '不外借');
INSERT INTO `allbook` VALUES ('002', '978-7-115-41064-1', '书库二', '未借出');
INSERT INTO `allbook` VALUES ('003', '978-7-115-41064-1', '书库二', '未借出');
INSERT INTO `allbook` VALUES ('004', '978-7-115-41064-1', '书库一', '未借出');
INSERT INTO `allbook` VALUES ('005', '978-7-115-41064-1', '阅览室', '不外借');
INSERT INTO `allbook` VALUES ('006', '978-7-115--37950-4', '书库一', '未借出');
INSERT INTO `allbook` VALUES ('007', '978-7-115--37950-4', '阅览室', '不外借');

-- ----------------------------
-- Table structure for booklist
-- ----------------------------
DROP TABLE IF EXISTS `booklist`;
CREATE TABLE `booklist`  (
  `ISBN` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `书名` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `作者` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `出版社` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `出版年月` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `册数` int(10) UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`ISBN`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of booklist
-- ----------------------------
INSERT INTO `booklist` VALUES ('978-7-115--37950-4', '数据结构C语言版', '严蔚敏', '人民邮电出版社', '2015-02', 2);
INSERT INTO `booklist` VALUES ('978-7-115-41064-1', '网站设计基础教程', '传智播客', '人民邮电出版社', '2016-03', 5);

-- ----------------------------
-- Table structure for log
-- ----------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log`  (
  `ID` int(12) NOT NULL,
  `图书ID` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `借出时间` datetime(0) NOT NULL,
  `应还时间` datetime(0) NULL DEFAULT NULL,
  `归还时间` datetime(0) NULL,
  PRIMARY KEY (`ID`, `图书ID`, `借出时间`) USING BTREE,
  INDEX `图书ID`(`图书ID`) USING BTREE,
  CONSTRAINT `log_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `user` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `log_ibfk_2` FOREIGN KEY (`图书ID`) REFERENCES `allbook` (`图书ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of log
-- ----------------------------
INSERT INTO `log` VALUES (666, '002', '2019-01-09 15:49:30', '2019-02-08 15:49:30', '2019-01-09 16:58:07');
INSERT INTO `log` VALUES (666, '002', '2019-01-09 17:03:26', '2019-02-08 17:03:26', '2019-01-09 17:06:52');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `ID` int(12) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (666, 'abc', 10086);

-- ----------------------------
-- Triggers structure for table allbook
-- ----------------------------
DROP TRIGGER IF EXISTS `afteraddbook`;
delimiter ;;
CREATE TRIGGER `afteraddbook` AFTER INSERT ON `allbook` FOR EACH ROW UPDATE booklist SET `册数`=`册数`+1 where ISBN=NEW.ISBN
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table allbook
-- ----------------------------
DROP TRIGGER IF EXISTS `afterdelbook`;
delimiter ;;
CREATE TRIGGER `afterdelbook` AFTER DELETE ON `allbook` FOR EACH ROW UPDATE booklist SET `册数`=`册数`-1 where ISBN=OLD.ISBN
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table log
-- ----------------------------
DROP TRIGGER IF EXISTS `beforeborrow`;
delimiter ;;
CREATE TRIGGER `beforeborrow` BEFORE INSERT ON `log` FOR EACH ROW SET new.`应还时间`=date_add(new.`借出时间`, interval 30 day)
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table log
-- ----------------------------
DROP TRIGGER IF EXISTS `afterborrow`;
delimiter ;;
CREATE TRIGGER `afterborrow` AFTER INSERT ON `log` FOR EACH ROW UPDATE allbook SET allbook.`状态`="已借出" where allbook.`图书ID`=NEW.`图书ID`
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table log
-- ----------------------------
DROP TRIGGER IF EXISTS `afterreturn`;
delimiter ;;
CREATE TRIGGER `afterreturn` AFTER UPDATE ON `log` FOR EACH ROW UPDATE allbook SET allbook.`状态`="未借出" where allbook.`图书ID`=NEW.`图书ID`
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
