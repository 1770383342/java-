/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Administrator
 */
public class JdbcUtil {
        private static String driverName = "com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql://localhost:3306/library?useUnicode=true&characterEncoding=GBK";
	private static String userName = "root";
	private static String password = "111111";
        
        public static Connection getConnection() throws SQLException {
		Connection conn = null;
		System.out.println("正在连接...");
		conn = DriverManager.getConnection(url, userName, password);
		System.out.println("连接成功!");
		return conn;

	}
}
