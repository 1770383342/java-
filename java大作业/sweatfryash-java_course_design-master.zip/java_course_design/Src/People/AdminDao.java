/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

/**
 *
 * @author 韩
 */
public interface AdminDao {
    public boolean login(String username,String password);
    public void addUser(String id,String name,String phone);
    public void updateUser(String id,String name,String phone);
    public void addBook(String id,String isbn,String location,String status );
    public void addBooklist(String isbn,String name,String author,String publisher,String birth);
}
