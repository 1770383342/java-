/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import AdminGui.AdduserFrame;
import AdminGui.AdminLoginFrame;
import AdminGui.AdminMainFrame;
import Jdbc.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author 韩
 */
public class AdminDaoImp implements AdminDao{

    @Override
    public boolean login(String username, String password) {
        Connection conn = null;
        PreparedStatement pstat = null;
        ResultSet rs = null;
        String sql="select * from admin where username=?";
        
        try {
            conn=JdbcUtil.getConnection();
            pstat=conn.prepareStatement(sql);
            pstat.setString(1,username);
            rs=pstat.executeQuery();
            if(rs.next()){
                String realpsd=rs.getString("psd");
                if(realpsd.equals(password)){
                    new AdminMainFrame().setVisible(true);
                    return true;
                }else{
                    System.out.println("密码错误，请重试");
                    return false;
                }
            }else{
                JOptionPane.showMessageDialog(null,"用户不存在！");
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminLoginFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    

    @Override
    public void addUser(String id, String name, String phone) {
        Connection conn = null;
        PreparedStatement pstat = null;
        ResultSet rs = null;
        String sql="select * from user where id=?";
        try {
                conn=JdbcUtil.getConnection();
                pstat=conn.prepareStatement(sql);
                pstat.setString(1, id);
                rs=pstat.executeQuery();
                if(rs.next()){
                    JOptionPane.showMessageDialog(null,"id不能重复！"); 
                }else{
                        sql="insert into user (id,name,phone) values(?,?,?)";
                        pstat=conn.prepareStatement(sql);
                        pstat.setString(1, id);
                        pstat.setString(2,name);
                        pstat.setString(3,phone);
                        int countrow=pstat.executeUpdate();
                        if(countrow==1)
                            JOptionPane.showMessageDialog(null,"用户添加成功！");  
                }
             }catch (SQLException ex) {
                Logger.getLogger(AdminDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    @Override
    public void updateUser(String id, String name, String phone) {
        Connection conn = null;
        PreparedStatement pstat = null;
        ResultSet rs = null;
        String sql="select * from user where id=?";
        try {
                conn=JdbcUtil.getConnection();
                pstat=conn.prepareStatement(sql);
                pstat.setString(1, id);
                rs=pstat.executeQuery();
                if(rs.next()){
                    sql="update user set name=?,phone=? where id=? ";
                    pstat=conn.prepareStatement(sql);
                    pstat.setString(1,name);
                    pstat.setString(2,phone);
                    pstat.setString(3,id);
                    int countrow=pstat.executeUpdate();
                    if(countrow==1)
                            JOptionPane.showMessageDialog(null,"信息更新成功！");   
                }else{
                      JOptionPane.showMessageDialog(null,"用户不存在！");   
                }
             }catch (SQLException ex) {
                Logger.getLogger(AdminDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void addBook(String id, String isbn, String location,String status) {
        Connection conn = null;
        PreparedStatement pstat = null;
        ResultSet rs = null;
        String sql="select * from booklist where ISBN=?";
        try {
            conn=JdbcUtil.getConnection();
            pstat=conn.prepareStatement(sql);
            pstat.setString(1, isbn);
            rs=pstat.executeQuery();
            if(rs.next()){
                sql="insert into allbook (图书id,isbn,存放位置,状态) values(?,?,?,?)";
                pstat=conn.prepareStatement(sql);
                pstat.setString(1,id);
                pstat.setString(2,isbn);
                pstat.setString(3,location);
                pstat.setString(4,status);
                int countrow=pstat.executeUpdate();
                if(countrow==1)
                            JOptionPane.showMessageDialog(null,"图书录入成功！");
            }else
                 JOptionPane.showMessageDialog(null,"没有对应的书目，请先完善信息创建书目");
        } catch (SQLException ex) {
            Logger.getLogger(AdminDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    @Override
    public void addBooklist(String isbn, String name, String author, String publisher, String birth) {
        Connection conn = null;
        PreparedStatement pstat = null;
        ResultSet rs = null;
        String sql="select * from booklist where ISBN=?";
        try {
            conn=JdbcUtil.getConnection();
            pstat=conn.prepareStatement(sql);
            pstat.setString(1, isbn);
            rs=pstat.executeQuery();
            if(rs.next()){
                 JOptionPane.showMessageDialog(null,"书目已存在！");
            }else{
                sql="insert into booklist (ISBN,书名,作者,出版社,出版年月,册数) values(?,?,?,?,?,?)";
                pstat=conn.prepareStatement(sql);
                pstat.setString(1,isbn);
                pstat.setString(2,name);
                pstat.setString(3,author);
                pstat.setString(4,publisher);
                pstat.setString(5,birth);
                pstat.setString(6,"0");
                int countrow=pstat.executeUpdate();
                if(countrow==1)
                            JOptionPane.showMessageDialog(null,"书目添加成功！");
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
