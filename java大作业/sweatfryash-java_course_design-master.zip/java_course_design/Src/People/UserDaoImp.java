/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Jdbc.JdbcUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class UserDaoImp implements UserDao{

    @Override
    public void borrowBook(String bookId, String userId, String time) {
        Connection conn = null;
        PreparedStatement pstat = null;
        ResultSet rs = null;
        String sql="select * from allbook where 图书ID=?";
        try {
                conn=JdbcUtil.getConnection();
                pstat=conn.prepareStatement(sql);
                pstat.setString(1,bookId);
                rs=pstat.executeQuery();
                if(rs.next()){
                    String status=rs.getString("状态");
                    if(status.equals("未借出")){
                        sql="insert into log (ID,图书ID,借出时间) values(?,?,?)";
                        pstat=conn.prepareStatement(sql);
                        pstat.setString(1,userId);
                        pstat.setString(2,bookId);
                        pstat.setString(3,time);
                        int countrow=pstat.executeUpdate();
                        if(countrow==1)
                            JOptionPane.showMessageDialog(null,"借书成功！");
                        }else if(status.equals("已借出")){
                            JOptionPane.showMessageDialog(null,"该书已借出！");
                        }else{
                        JOptionPane.showMessageDialog(null,"阅览室图书不外借！");
                    }
              }else{
                    JOptionPane.showMessageDialog(null,"输入的书号不存在，请重试！");
                }
        } catch (SQLException ex) {
            Logger.getLogger(UserDaoImp.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"用户不存在，请重试！");
        }
    }

    @Override
    public void returnBook(String bookId, String userId, String time) {          //还书
        Connection conn = null;
        PreparedStatement pstat = null;
        ResultSet rs = null;
        String sql="select * from log where 图书ID=? and ID=? and 归还时间='0000-00-00 00:00:00'";
        try {                                                           //数据库里设的默认值，为了区分记录
            conn=JdbcUtil.getConnection();
            pstat=conn.prepareStatement(sql);
            pstat.setString(1,bookId);
            pstat.setString(2,userId);
            rs=pstat.executeQuery();
            if(rs.next()){
                  sql="update log set 归还时间= ? where 图书ID= ? and ID= ? and 归还时间='0000-00-00 00:00:00'";
                  pstat=conn.prepareStatement(sql);
                  pstat.setString(1,time);
                  pstat.setString(2,bookId);
                  pstat.setString(3,userId);
                  int countrow=pstat.executeUpdate();
                  if(countrow==1){
                      JOptionPane.showMessageDialog(null,"还书成功！");
                      }
              }else{
               JOptionPane.showMessageDialog(null,"信息有误，请重试！"); 
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDaoImp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
